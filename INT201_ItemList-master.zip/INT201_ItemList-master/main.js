import { products } from "./data/products.js";
import { itemList } from "./itemList.js";

const { initialPage } = itemList(products)
initialPage()




